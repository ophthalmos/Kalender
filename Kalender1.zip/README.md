# Kalender
Monatskalender mit Datumsübernahme in andere Anwendungen

![](https://img.shields.io/github/release-date/ophthalmos/kalender.svg?style=flat)
![](https://img.shields.io/github/downloads/ophthalmos/kalender/latest/total.svg?style=flat)
![](https://img.shields.io/github/license/ophthalmos/kalender.svg?style=flat)
